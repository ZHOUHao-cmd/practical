
first_name='zhou'
last_name='hao'
full_name=f"{first_name}{last_name}"#插入字符段
print(full_name)
print('zhou')
print('\tzhou')#制表符（\t是制表符，\n是换行符）
fav="zhouhao "#fav是变量
print(fav.rstrip())#去掉空格
bicycle=['one','two','three','four']
print(bicycle[0])#索引0.1.2.3同时有负数-1.2.-3.-4
massage=f"i haxe a book is {bicycle[2].title()}"
print(massage)