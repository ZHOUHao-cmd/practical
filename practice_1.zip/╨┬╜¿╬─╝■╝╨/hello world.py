print('\"i love python".\\n')
print('\"python is good."\\n')
